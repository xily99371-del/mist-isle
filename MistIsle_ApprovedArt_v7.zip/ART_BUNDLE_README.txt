Mist Isle approved art bundle v7
- Watcher sprite sheet is the exact user-selected final 4x4 image, prepared as 64x80 frames.
- Lighthouse Guardian uses a regenerated valid 4x2 pixel sprite sheet, 64x80 frames.
- Six full-resolution lossless PNG anime portraits are dialogue/card-only.
- Heroine uses the approved 4x4 pixel sheet for world movement.
