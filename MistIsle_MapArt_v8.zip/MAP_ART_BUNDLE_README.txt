Mist Isle Map Art v8
Four generated transparent pixel-art prop sheets for the four Tiled areas.
These are source sheets. Runtime draws individually cropped sprites from fixed source rectangles.
No detached circular shadows should be drawn for any map decoration.
